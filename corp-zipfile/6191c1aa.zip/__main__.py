# -*- coding: utf-8 -*-
import pkg.mod
pkg.mod.fn()
