
import importlib.resources as res
val = res.files().joinpath('res.txt').read_text(encoding='utf-8')
